// eslint-disable-next-line no-unused-vars
import React, { useContext } from "react";
import { ShopContext } from "../../context/shop-context";

export const Product = (props) => {
  // eslint-disable-next-line react/prop-types
  const { id, productName, Description,price, productImage } = props.data;
  const { addToCart, cartItems } = useContext(ShopContext);

  const cartItemCount = cartItems[id];

  return (
    <div className="product">
      <img src={productImage} />
      <div className="description">
        <p style={{color:'black',fontWeight:'700'}}>
          <b>{productName}</b>
        </p>
        <p style={{color:'black'}}>{Description}</p>
        <p style={{color:'black'}}> ${price}</p>
      </div>

      <button className="addToCartBttn" onClick={() => addToCart(id)}>
        
        Add To Cart {cartItemCount > 0 && <> ({cartItemCount})</>}
      </button>
    </div>
  );
};