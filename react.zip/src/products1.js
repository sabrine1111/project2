import product1 from "./assets/1.png";
import product2 from "./assets/2.png";
import product3 from "./assets/3.png";
import product4 from "./assets/4.png";
import product5 from "./assets/5.png";


export const PRODUCTS = [
  {
    id: 1,
    productName: "product1", 
    DescriptionDescription:": A timeless classic, the Datejust combines elegance with functionality. Its hallmark feature is the date window at 3 o'clock magnified by the Cyclops lens",

    price: 999.0,
    productImage: product1,
    },
  {
    id: 2,
    productName: "product2",
    Description:"",

    price: 1999.0,
    productImage: product2,
  },
  {
    id: 3,
    productName: "product3",
    Description:"",

    price: 699.0,
    productImage: product3,
  },
  {
    id: 4,
    productName: "product4",
    Description:"",

    price: 228.0,
    productImage: product4,
  },
  {
    id: 5,
    productName: "product5",
    Description:"",
   
    price: 199.99,
    productImage: product5,
  },
  {
    id: 6,
    productName: "Rolex Day-Date",
    Description:" Often referred to as the President's watch, the Day-Date is renowned for displaying both the date and the day of the week spelled out in full. It exudes luxury and sophistication.",
   
    price: 160.0,
    productImage: product4,
  },
  {
    id: 7,
    productName: "Rolex Sea-Dweller",
    Description:": Designed for professional divers, the Sea-Dweller offers an impressive water resistance of up to 1,220 meters (4,000 feet). Its helium escape valve ensures reliability during deep-sea exploration.",
    price: 190.0,
    productImage: product2,
  },
  {
    id: 8,
    productName: "Rolex Yacht-Master",
    Description:"Inspired by the world of sailing, the Yacht-Master features a rotatable bezel with raised numerals for tracking elapsed time. Its nautical aesthetic and robust construction make it a favorite among sailors and yachting enthusiasts.",
    price: 140.0,
    productImage: product3,
  },
];