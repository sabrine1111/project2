import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Navbar } from "./components/navbar";
import { Shop } from "./pages/shop/shop";
import { Contact } from "./pages/shop/contact"; // Assuming you have this component
import { Cart } from "./pages/cart/cart";
import SignIn from "./pages/singin/singin"; // Import the SignIn component
import { ShopContextProvider } from "./context/shop-context";
import { Favorite } from "./pages/shop/Favorite";
import Login from "./pages/Login/login";


function App() {
  return (
    <ShopContextProvider>
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Shop />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/favorite" element={<Favorite />} /> {/* Assuming you have a Favorite component */}
          <Route path="/cart" element={<Cart />} />
          <Route path="/signin" element={<SignIn />} /> {/* Add the sign-in route */}
          <Route path="/login" element={<Login />}/>
        </Routes>
      </Router>
    </ShopContextProvider>
  );
}

export default App;
